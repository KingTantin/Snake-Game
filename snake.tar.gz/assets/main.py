import pygame
from sys import exit
import random
from collections import deque

import asyncio


def collected_apple(screen, move_list, length, screen_width, screen_height, base_length, text_font):

    if len(move_list)+1 > (screen_width-screen_width//4)//base_length*(screen_height//base_length):
        print('f')
        continue_surface1 = text_font.render('You have', False, 'Green')
        screen.blit(continue_surface1, (screen_width//40, screen_height//2))

        continue_surface2 = text_font.render('won', False, 'Green')
        screen.blit(continue_surface2, (screen_width//40, screen_height//2 + text_font.get_height()))
        quit()


    length += 10
    while True:
        random_spawnpoint = [base_length*random.randint(screen_width//4//base_length, screen_width//base_length-1), base_length*random.randint(0, screen_height//base_length-1)]
        if random_spawnpoint not in move_list:
            break
        

    apple = pygame.draw.rect(screen, (255, 0, 0), (random_spawnpoint[0], random_spawnpoint[1], base_length, base_length))
    return length, apple


def refresh_info(screen, headline_font, text_font, length):
    rect_width = screen_width//4-1

    pygame.draw.rect(screen, (0, 0, 0), (0, 0, rect_width , screen_height))

    headline_surface = headline_font.render('Snake', False, 'Green')
    screen.blit(headline_surface, (rect_width//10, screen_height//10))

    score_surface = text_font.render('Score:', False, 'Green')
    screen.blit(score_surface, (rect_width//10, screen_height//3))

    score_point_surface = text_font.render(str(length-1), False, 'Green')
    screen.blit(score_point_surface, (rect_width//10+4*text_font.get_height(), screen_height//3))

    pygame.draw.rect(screen, (30, 30, 30), (screen_width//4-1, 0, 1, screen_height))    #pufferzone
    pygame.display.update()


async def game_over(move_list: list, screen, text_font, headline_font, base_length: int, start_position: list):

    continue_surface1 = text_font.render('Press Enter', False, 'Green')
    screen.blit(continue_surface1, (screen_width//40, screen_height//2))

    continue_surface2 = text_font.render('to continue', False, 'Green')
    screen.blit(continue_surface2, (screen_width//40, screen_height//2 + text_font.get_height()))

    pygame.display.update()
    while True:
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:

                    

                    for position in range(len(move_list)-1):
                        
                        refresh_info(screen, headline_font, text_font, len(move_list)-1-position)


                        pygame.draw.rect(screen, (30, 30, 30), (move_list[position][0], move_list[position][1], base_length, base_length))
                        await asyncio.sleep(0.01)

                    refresh_info(screen, headline_font, text_font, 1)  
                    return start_position, [start_position], (1, 0), 1      
        await asyncio.sleep(0)

async def main(screen_width: int, screen_height: int, start_position: list, base_length: int, fps_cap):
    pygame.init()


    screen = pygame.display.set_mode((screen_width, screen_height))
    screen.fill('Red')
    pygame.display.set_caption('Snake')

    clock = pygame.time.Clock()


    position = start_position.copy()


    direction = (1, 0)
    length = 1



    try:
        #headline_font = pygame.font.Font('Snake/PixelColeco-4vJW.ttf', screen_width//20)
        #text_font = pygame.font.Font('Snake/PixelColeco-4vJW.ttf', screen_width//40)
        headline_font = pygame.font.Font('PixelColeco-4vJW.ttf', screen_width//20)
        text_font = pygame.font.Font('PixelColeco-4vJW.ttf', screen_width//40)
    except:
        headline_font = pygame.font.SysFont('Arial', screen_width//20)
        text_font = pygame.font.SysFont('Arial', screen_width//40)



    refresh_info(screen, headline_font, text_font, length)

    background = pygame.draw.rect(screen, (30, 30, 30), (screen_width//4, 0, screen_width-(screen_width//4), screen_height))


    apple = pygame.draw.rect(screen, (255, 0, 0), (base_length*random.randint(screen_width//4//base_length, screen_width//base_length-1), 
                                                   base_length*random.randint(0, screen_height//base_length-1), base_length, base_length))


    move_list = [start_position]

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w and direction != (0, -1):
                    direction = (0, 1)

                elif event.key == pygame.K_d and direction != (-1, 0):
                    direction = (1, 0)

                elif event.key == pygame.K_s and direction != (0, 1):
                    direction = (0, -1)

                elif event.key == pygame.K_a and direction != (1, 0):
                    direction = (-1, 0)
                break

        #update position
        position[0] += base_length*direction[0]
        position[1] -= base_length*direction[1]



        move_list.append(position.copy())

        pygame.draw.rect(screen, (30, 30, 30), (move_list[0][0], move_list[0][1], base_length, base_length))





        if length < len(move_list):

            move_list = move_list[1: len(move_list)]

        

        player = pygame.draw.rect(screen, (0, 255, 0), (position[0], position[1], base_length, base_length))


        if position in move_list[0: len(move_list)-1]:

            position, move_list, direction, length = await game_over(move_list, screen, text_font, headline_font, base_length, start_position.copy())


        if not player.colliderect(background):


            refresh_info(screen, headline_font, text_font, length)
            position, move_list, direction, length = await game_over(move_list, screen, text_font, headline_font, base_length, start_position.copy())


 
        
        if player.colliderect(apple):

            length, apple = collected_apple(screen, move_list, length, screen_width, screen_height, base_length, text_font)
            refresh_info(screen, headline_font, text_font, length)


        



        pygame.display.update()
        clock.tick(fps_cap)
        await asyncio.sleep(0)


screen_width = 2400                   #try to make sure that screen_width and screen_height are divisors of base_length (for better allingment)
screen_height = 1300
base_length= 20
fps_cap = 30                          #screen_width//base_length//5      #travel the whole screen in 5 sec

start_position = [screen_width//base_length//3*base_length, screen_height//base_length//2*base_length] #always a centered star_position

asyncio.run(main(screen_width, screen_height, start_position, base_length, fps_cap))