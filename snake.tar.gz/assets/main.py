import pygame
from sys import exit
import random
from collections import deque
from time import sleep
import asyncio


def tail_logic(length, move_list):

    if length < len(move_list):

        return move_list[1: len(move_list)]
    return move_list


async def game_over(move_list, screen, text_font):

    continue_surface1 = text_font.render('Press Enter', False, 'Green')
    screen.blit(continue_surface1, (10, 225))

    continue_surface2 = text_font.render('to continue', False, 'Green')
    screen.blit(continue_surface2, (10, 250))

    pygame.display.update()
    while True:
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:

                    

                    for position in range(len(move_list)-1):
                        
                        pygame.draw.rect(screen, (0, 0, 0), (125, 100, 75, 300))
                        score_point_surface = text_font.render(str(len(move_list)-2-position), False, 'Green')
                        screen.blit(score_point_surface, (125, 100))


                        pygame.draw.rect(screen, (30, 30, 30), (move_list[position][0], move_list[position][1], 5, 5))
                        pygame.display.update()
                        await asyncio.sleep(0.01)

                    
                    pygame.draw.rect(screen, (0, 0, 0), (10, 225, 190, 50))
                    return (1, 0, 0, 0), 450, 200, 1
        await asyncio.sleep(0)

async def main():
    pygame.init()

    screen_width = 800
    screen_height = 400
    screen = pygame.display.set_mode((screen_width, screen_height))

    pygame.display.set_caption('Snake')

    clock = pygame.time.Clock()



    direction = (1, 0, 0, 0)
    x_position = 450
    y_position = 200
    length = 1




    headline_font = pygame.font.Font('pixel-coleco-font/PixelColeco-4vJW.ttf', 50)
    text_font = pygame.font.Font('pixel-coleco-font/PixelColeco-4vJW.ttf', 25)
    #except:
    #    headline_font = pygame.font.SysFont('Arial', 50)
    #    text_font = pygame.font.SysFont('Arial', 25)




    headline_surface = headline_font.render('Snake', False, 'Green')
    screen.blit(headline_surface, (10,10))

    score_surface = text_font.render('Score:', False, 'Green')
    screen.blit(score_surface, (15, 100))

    score_point_surface = text_font.render(str(length-1), False, 'Green')
    screen.blit(score_point_surface, (125, 100))



    background = pygame.draw.rect(screen, (30, 30, 30), (200, 0, 700, 400))
    apple = pygame.draw.rect(screen, (255, 0, 0), (5*random.randint(40, 159), 5*random.randint(0, 79), 5, 5))


    move_list = [(x_position, y_position)]
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w and direction != (0, 0, 1, 0):
                    direction = (0, 0, 0, 1)

                elif event.key == pygame.K_d and direction != (0, 1, 0, 0):
                    direction = (1, 0, 0, 0)

                elif event.key == pygame.K_s and direction != (0, 0, 0, 1):
                    direction = (0, 0, 1, 0)

                elif event.key == pygame.K_a and direction != (1, 0, 0, 0):
                    direction = (0, 1, 0, 0)
                break
            

        x_position += 5*direction[0]
        x_position -= 5*direction[1]
        y_position += 5*direction[2]
        y_position -= 5*direction[3]


        taile = pygame.draw.rect(screen, (30, 30, 30), (move_list[0][0], move_list[0][1], 5, 5))


        move_list.append((x_position, y_position))
        move_list = tail_logic(length, move_list)



        

        player = pygame.draw.rect(screen, (0, 255, 0), (x_position, y_position, 5, 5))
        

        if (x_position, y_position) in move_list[0: len(move_list)-1]:
            direction, x_position, y_position, length = await game_over(move_list, screen, text_font)
            move_list = [(x_position, y_position)]

        if not player.colliderect(background):

            pygame.draw.rect(screen, (0, 0, 0), (x_position, y_position, 5, 5))
            direction, x_position, y_position, length = await game_over(move_list, screen, text_font)
            move_list = [(x_position, y_position)]
        
        if player.colliderect(apple):

            length += 10

            pygame.draw.rect(screen, (0, 0, 0), (125, 100, 75, 300))
            score_point_surface = text_font.render(str(length-1), False, 'Green')
            screen.blit(score_point_surface, (125, 100))

            apple = pygame.draw.rect(screen, (255, 0, 0), (5*random.randint(40, 159), 5*random.randint(0, 79), 5, 5))


        



        pygame.display.update()
        clock.tick(30)
        await asyncio.sleep(0)

asyncio.run(main())